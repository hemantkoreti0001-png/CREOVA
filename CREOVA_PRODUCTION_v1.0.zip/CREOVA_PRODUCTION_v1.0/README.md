# CREOVA Production v1.0

Phone-first deployment foundation for CREOVA.

## Backend
- NestJS API
- PostgreSQL + Prisma
- JWT authentication
- User profiles
- Posts/content
- Video metadata
- Likes/views
- Tribes
- Basic live-stream records
- Membership/tips/ads records
- Moderation/report/copyright records
- CORS enabled
- Health endpoint: `GET /health`

## Render
Create a Render Web Service from this repository.

If the repository contains this project at the root:
- Root Directory: `backend`
- Build Command: `npm install && npx prisma generate && npm run build`
- Start Command: `npx prisma db push --accept-data-loss && npm start`

Environment variables:
- `DATABASE_URL`
- `JWT_SECRET`
- `PORT` (optional; Render supplies PORT)
- `NODE_ENV=production`

Do not upload `.env` or secret keys to GitHub.

## Important
This is a deployable backend foundation, not the complete CREOVA production platform. Video files still need object storage/CDN (for example Supabase Storage or another provider), and payments, live streaming infrastructure, moderation automation, and mobile API integration need to be connected before public launch.
